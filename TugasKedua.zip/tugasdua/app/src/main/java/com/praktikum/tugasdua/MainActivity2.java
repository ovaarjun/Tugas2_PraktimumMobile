package com.praktikum.tugasdua;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity {
    TextView Tnama,Tnim,Tnilai;
    String viewnama;
    Integer viewnim,viewnilai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Tnama = (TextView) findViewById(R.id.viewnama);
        Tnim = (TextView) findViewById(R.id.viewnim);
        Tnilai = (TextView) findViewById(R.id.viewnilai);
        Bundle b = getIntent().getExtras();
        viewnama = b.getString("parse_nama");
        viewnim = b.getInt("parse_nim");
        viewnilai = b.getInt("parse_nilai");

        Tnama.setText(" "+ viewnama);
        Tnim.setText(" "+ viewnim);
        if (viewnilai >= 3.6 ) {
            Tnilai.setText(" A+"+ viewnilai);
        } else if (viewnilai >= 3.3 || viewnilai <= 3.6) {
            Tnilai.setText(" A- "+ viewnilai);
        }  else if (viewnilai >= 3 || viewnilai <= 3.3) {
            Tnilai.setText(" B+ " + viewnilai);
        } else if (viewnilai >= 2.6 || viewnilai <= 3) {
            Tnilai.setText(" B " + viewnilai);
        }  else if (viewnilai >= 2.3 || viewnilai <= 2.6) {
            Tnilai.setText(" B- " + viewnilai);
        }  else if (viewnilai >= 2 || viewnilai <= 2.3) {
            Tnilai.setText(" C+ " + viewnilai);
        }  else if (viewnilai >= 1.6 || viewnilai <= 2) {
            Tnilai.setText(" C " + viewnilai);
        }  else if (viewnilai >= 1.3 || viewnilai <= 1.6) {
            Tnilai.setText(" C- " + viewnilai);
        }  else if (viewnilai >= 1 || viewnilai <= 1.3) {
            Tnilai.setText(" D+ " + viewnilai);
        }  else if (viewnilai > 1 ) {
            Tnilai.setText(" D " + viewnilai);
        }
    }
}