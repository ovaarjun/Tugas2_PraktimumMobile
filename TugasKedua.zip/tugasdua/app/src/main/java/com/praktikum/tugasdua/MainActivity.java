package com.praktikum.tugasdua;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    String Inama;
    Integer Inim, Inilai;
    EditText Inputnama,Inputnim,Inputnilai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Inputnama = (EditText) findViewById(R.id.nama);
        Inputnim = (EditText) findViewById(R.id.nim);
        Inputnilai = (EditText) findViewById(R.id.nilai);

        Button submit = (Button)findViewById(R.id.simpan);
        submit.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Inama = Inputnama.getText().toString();
                Inim = Inputnim.getText().length();
                Inilai = Inputnilai.getText().length();

                if(Inama.equals("")){
                    Toast.makeText(MainActivity.this, "Semua form harus di isi!", Toast.LENGTH_LONG).show();
                }else{
                    Intent i = null;
                    i = new Intent(MainActivity.this, MainActivity2.class);
                    Bundle b = new Bundle();
                    b.putString("parse_nama",Inama);
                    b.putInt("parse_nim",Inim);
                    b.putInt("parse_nilai",Inilai);
                    i.putExtras(b);
                    startActivity(i);
                }
            }
        });

    }
}